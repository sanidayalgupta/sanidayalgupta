from django.db import models
from django.forms import ValidationError
from django.core.validators import MaxValueValidator,MinValueValidator
from django.contrib.auth.models import User
# Create your models here.

def alphanumeric(value):
    if not str(value).isalnum():
        raise ValidationError("%(value)s contains non-alphanumeric characters.", params={'value': value},)
    
class Showroomlist(models.Model):
    name=models.CharField(max_length=100)
    location=models.CharField(max_length=100)
    website=models.URLField(max_length=100)
    
    def __str__(self):
        return self.name

class Carlist(models.Model):
    name=models.CharField(max_length=100)
    description=models.TextField()
    active=models.BooleanField(default=False)
    chasisnumber=models.CharField(max_length=100,blank=True,null=True,validators=[alphanumeric])
    price=models.DecimalField(max_digits=9,decimal_places=2,blank=True,null=True)
    showroom=models.ForeignKey(Showroomlist,on_delete=models.CASCADE,related_name='Showrooms',blank=True,null=True)

    def __str__(self):
        return self.name
    
class Review(models.Model):
    apiUser=models.ForeignKey(User, on_delete=models.CASCADE)
    rating=models.IntegerField(validators=[MaxValueValidator,MinValueValidator])
    comments=models.TextField()
    car=models.name = models.ForeignKey(Carlist, related_name='Reviews', on_delete=models.CASCADE,null=True)    
    created=models.DateTimeField(auto_now_add=True)
    updated=models.DateTimeField(auto_now=True)

    def __str__(self):
        return "the rating of "+self.car.name+"-----------"+str(self.rating)