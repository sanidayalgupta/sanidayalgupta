from django.contrib import admin
from .models import Carlist,Showroomlist,Review
# Register your models here.
class CarAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'active', 'chasisnumber','price')

admin.site.register(Carlist,CarAdmin)       
admin.site.register(Showroomlist)
admin.site.register(Review) 