from django.shortcuts import render
from .models import Carlist,Showroomlist,Review
from django.http import JsonResponse,HttpResponse
from .api_file.serializers import CarSerializer,ShowroomSerializer,ReviewSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.views import APIView
from rest_framework import mixins,generics
from rest_framework.authentication import BasicAuthentication, SessionAuthentication, TokenAuthentication
from rest_framework.permissions import IsAuthenticated, AllowAny, IsAdminUser, DjangoModelPermissions
from rest_framework import viewsets
from django.shortcuts import get_object_or_404
from rest_framework.exceptions import ValidationError
from .api_file.permissions import AdminOrReadOnlyPermission, ReviewUserOrReadOnly
from rest_framework_simplejwt.authentication import JWTAuthentication
# Create your views here.

# def car_list_view(request):
#     cars=Carlist.objects.all()
#     data={
#         'cars':list(cars.values()),
#     }
#     # return JsonResponse(data)
#     json_data=json.dumps(data)
#     return HttpResponse(json_data,content_type="application/json")

# def car_detail_view(request,pk):
#     car=Carlist.objects.get(id=pk)
#     data={
#         'name':car.name,
#         'description':car.description,
#         'active':car.active
#     }
#     return JsonResponse(data)

class ReviewList(generics.ListAPIView):
    #queryset = Review.objects.all()
    serializer_class = ReviewSerializer
    authentication_classes=[JWTAuthentication]
    permission_classes=[AdminOrReadOnlyPermission]
    def get_queryset(self):
        pk=self.kwargs['pk']
        return Review.objects.filter(car=pk)
    
class ReviewCreate(generics.CreateAPIView):
    serializer_class=ReviewSerializer

    def get_queryset(self):
        return Review.objects.all()
    def perform_create(self, serializer):
        pk=self.kwargs['pk']
        cars=Carlist.objects.get(id=pk)
        useredit=self.request.user
        Review_quesryset=Review.objects.filter(car=cars,apiUser=useredit)
        if Review_quesryset.exists():
            raise ValidationError("You have already reviewed this car")
        serializer.save(car=cars,apiUser=useredit) 

class ReviewDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer

    # permission_classes=[AdminOrReadOnlyPermission]
    authentication_classes=[TokenAuthentication]
    permission_classes=[ReviewUserOrReadOnly]

# class ReviewDetail(mixins.RetrieveModelMixin,mixins.UpdateModelMixin,mixins.DestroyModelMixin,generics.GenericAPIView):
#     queryset=Review.objects.all()
#     serializer_class=ReviewSerializer

#     def get(self,request,*args, **kwargs):
#         return self.retrieve(request,*args, **kwargs)
    
#     def put(self,request,*args, **kwargs):
#         return self.update(request,*args, **kwargs)
    
#     def delete(self,request,*args, **kwargs):
#         return self.destroy(request,*args, **kwargs)

# class ReviewList(mixins.ListModelMixin,mixins.CreateModelMixin,generics.GenericAPIView):
#     queryset=Review.objects.all()
#     serializer_class=ReviewSerializer

#     authentication_classes= [SessionAuthentication]
#     permission_classes=[DjangoModelPermissions]

#     def get(self,request,*args, **kwargs):
#         return self.list(request,*args, **kwargs)

#     def post(self,request,*args, **kwargs):
#         return self.create(request,*args, **kwargs)

@api_view(['GET','POST'])
def car_list_view(request):
    if request.method == 'GET':
        cars=Carlist.objects.all()
        serializer=CarSerializer(cars,many=True)
        return Response(serializer.data)
    if request.method == 'POST':
        serializer = CarSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        else:
            return Response(serializer.errors, status=400)
        

@api_view(['GET', 'PUT','DELETE'])
def car_detail_view(request,pk):
    if request.method == 'GET':
        try:
            car=Carlist.objects.get(id=pk)
        except:
            return Response({'error': 'Car not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer=CarSerializer(car)
        return Response(serializer.data)
    if request.method == 'PUT':
        car=Carlist.objects.get(id=pk)
        serializer = CarSerializer(car,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    if request.method == 'DELETE':
        car=Carlist.objects.get(id=pk)
        car.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)    

# class Showroom_Viewset(viewsets.ViewSet):
#     def list(self,request):
#         showroom=Showroomlist.objects.all()
#         serializer=ShowroomSerializer(showroom,many=True,context={'request':request})
#         return Response(serializer.data)
    
#     def retrieve(self, request, pk=None):
#         showroom = Showroomlist.objects.all()
#         user = get_object_or_404(showroom, pk=pk)
#         serializer = ShowroomSerializer(user)
#         return Response(serializer.data)
       
#     def create(self, request):
#         serializer = ShowroomSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=status.HTTP_201_CREATED)
#         else:
#             return Response({'error': 'Invalid data provided'}, status=status.HTTP_400_BAD_REQUEST)
    
# class Showroom_Viewset(viewsets.ModelViewSet):
#     queryset = Showroomlist.objects.all()
#     serializer_class = ShowroomSerializer

class Showroom_Viewset(viewsets.ReadOnlyModelViewSet):
    queryset = Showroomlist.objects.all()
    serializer_class = ShowroomSerializer

class Showroom_View(APIView):
    # authentication_classes = [BasicAuthentication]
    # permission_classes=[IsAuthenticated]
    # permission_classes=[AllowAny]
    # permission_classes=[IsAdminUser]
    # authentication_classes = [SessionAuthentication]
    # permission_classes=[IsAuthenticated]
    # permission_classes=[IsAdminUser]
    def get(self, request):
        showroom=Showroomlist.objects.all()
        serializer=ShowroomSerializer(showroom,many=True,context={'request':request})
        return Response(serializer.data)

    def post(self,request):
        serializer=ShowroomSerializer(data=request.data)  
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response({'error': 'Invalid data provided'}, status=status.HTTP_400_BAD_REQUEST)
        

class Showroom_detail_view(APIView):
    def get(self,request,pk):
        try:
            showroom=Showroomlist.objects.get(id=pk)
        except Showroomlist.DoesNotExist:
            return Response({'error': 'Showroom not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer=ShowroomSerializer(showroom)
        return Response(serializer.data)
    
    def put(self,request,pk):
        showroom=Showroomlist.objects.get(id=pk)
        serializer=ShowroomSerializer(showroom,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response({'error': 'Invalid data provided'}, status=status.HTTP_400_BAD_REQUEST)
        
    def delete(self,request,pk):
        showroom=Showroomlist.objects.get(id=pk)
        showroom.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)    