import requests

endPoints="http://127.0.0.1:8000/car/list/"

getResponse=requests.get(endPoints)
print(getResponse.json())
print(getResponse.status_code)