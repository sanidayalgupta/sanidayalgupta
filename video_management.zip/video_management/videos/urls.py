from django.urls import path
from .views import VideoUploadView, VideoSearchView, BlockVideoView, VideoDownloadView

urlpatterns = [
    path('upload/', VideoUploadView.as_view(), name='upload_video'),
    path('search/', VideoSearchView.as_view(), name='search_videos'),
    path('block/<int:video_id>/', BlockVideoView.as_view(), name='block_video'),
    path('download/<int:video_id>/', VideoDownloadView.as_view(), name='download_video'),
]
