from django.contrib import admin
from .models import Video, BlockedVideo

@admin.register(Video)
class VideoAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'size', 'created_at')

@admin.register(BlockedVideo)
class BlockedVideoAdmin(admin.ModelAdmin):
    list_display = ('id', 'video', 'blocked_at')
