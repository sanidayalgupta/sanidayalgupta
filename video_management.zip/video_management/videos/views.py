import os
import uuid
import ffmpeg
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from .models import Video, BlockedVideo

# 1. Upload Video API (converts to .mp4)
class VideoUploadView(APIView):
    def post(self, request, *args, **kwargs):
        if 'file' not in request.FILES:
            return Response({'error': 'No file uploaded'}, status=status.HTTP_400_BAD_REQUEST)
        
        file = request.FILES['file']
        filename = f"{uuid.uuid4()}_{file.name}"
        upload_dir = os.path.join(settings.MEDIA_ROOT, 'videos')

        # Save the uploaded file
        fs = FileSystemStorage(location=upload_dir)
        fs.save(filename, file)
        input_path = os.path.join(upload_dir, filename)

        # Convert to .mp4
        output_filename = f"{uuid.uuid4()}.mp4"
        output_path = os.path.join(upload_dir, output_filename)
        ffmpeg.input(input_path).output(output_path, format='mp4').run()

        # Save video metadata to the database
        video = Video.objects.create(name=file.name, size=os.path.getsize(output_path), path=output_path)

        # Optionally delete the original file
        os.remove(input_path)

        return Response({'message': 'Video uploaded and converted', 'video_id': video.id}, status=status.HTTP_201_CREATED)

# 2. Search Videos API (search by name or size)
class VideoSearchView(APIView):
    def get(self, request, *args, **kwargs):
        name = request.GET.get('name', None)
        size = request.GET.get('size', None)

        videos = Video.objects.all()
        if name:
            videos = videos.filter(name__icontains=name)
        if size and size.isdigit():
            videos = videos.filter(size=int(size))

        video_list = [{'id': v.id, 'name': v.name, 'size': v.size} for v in videos]
        return Response(video_list, status=status.HTTP_200_OK)

# 3. Block Video API (blocks video download by ID)
class BlockVideoView(APIView):
    def post(self, request, video_id, *args, **kwargs):
        try:
            video = Video.objects.get(id=video_id)
        except Video.DoesNotExist:
            return Response({'error': 'Video not found'}, status=status.HTTP_404_NOT_FOUND)

        BlockedVideo.objects.create(video=video)
        return Response({'message': f'Video {video.name} blocked'}, status=status.HTTP_200_OK)

# 4. Download Video API (checks if video is blocked)
class VideoDownloadView(APIView):
    def get(self, request, video_id, *args, **kwargs):
        try:
            video = Video.objects.get(id=video_id)
        except Video.DoesNotExist:
            return Response({'error': 'Video not found'}, status=status.HTTP_404_NOT_FOUND)

        if BlockedVideo.objects.filter(video=video).exists():
            return Response({'error': 'Video is blocked'}, status=status.HTTP_403_FORBIDDEN)

        # Return the video file
        return Response(open(video.path, 'rb'), content_type='video/mp4', headers={
            'Content-Disposition': f'attachment; filename="{video.name}"',
        })
