from django.db import models

class Video(models.Model):
    name = models.CharField(max_length=255)
    size = models.PositiveIntegerField()
    path = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

class BlockedVideo(models.Model):
    video = models.ForeignKey(Video, on_delete=models.CASCADE)
    blocked_at = models.DateTimeField(auto_now_add=True)
