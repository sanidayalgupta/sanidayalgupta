from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from .models import Video, BlockedVideo

class VideoAPITest(APITestCase):

    def test_upload_video(self):
        with open('test_video.mp4', 'rb') as video:
            response = self.client.post(reverse('upload_video'), {'file': video})
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_search_videos(self):
        Video.objects.create(name="Test Video", size=1024, path="test_video.mp4")
        response = self.client.get(reverse('search_videos'), {'name': 'Test'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_block_video(self):
        video = Video.objects.create(name="Blockable Video", size=1024, path="blockable_video.mp4")
        response = self.client.post(reverse('block_video', args=[video.id]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_download_video(self):
        video = Video.objects.create(name="Downloadable Video", size=1024, path="downloadable_video.mp4")
        response = self.client.get(reverse('download_video', args=[video.id]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_blocked_video_cannot_download(self):
        video = Video.objects.create(name="Blocked Video", size=1024, path="blocked_video.mp4")
        BlockedVideo.objects.create(video=video)
        response = self.client.get(reverse('download_video', args=[video.id]))
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
